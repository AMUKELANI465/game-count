import { Link } from "react-router-dom";
import { Camera, ScanSearch, ListOrdered, UserCheck, Database, PawPrint } from "lucide-react";

const steps = [
  { icon: Camera, label: "Aerial Image" },
  { icon: ScanSearch, label: "AI Detection" },
  { icon: ListOrdered, label: "Species Count" },
  { icon: UserCheck, label: "Ranger Verification" },
  { icon: Database, label: "Census Record" },
];

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-forest-800 to-forest-900 text-white">
      <header className="max-w-5xl mx-auto px-6 pt-16 pb-10 text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <PawPrint className="text-accent-400" size={30} />
          <span className="text-sm uppercase tracking-[0.2em] text-forest-200">Welgevonden Game Reserve · Limpopo</span>
        </div>
        <h1 className="text-4xl md:text-5xl font-extrabold tracking-tight">GAME COUNT</h1>
        <p className="text-xl md:text-2xl text-forest-100 mt-3 font-medium">
          Making wildlife census faster with AI-assisted counting.
        </p>
        <p className="max-w-2xl mx-auto text-forest-200 mt-5 leading-relaxed">
          Game Count helps game rangers analyse aerial wildlife imagery, identify visible animals and generate a
          first-pass count that can be reviewed and verified by conservation personnel.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center mt-8">
          <Link
            to="/new-survey"
            className="bg-accent-500 hover:bg-accent-600 transition-colors text-white font-semibold px-6 py-3 rounded-lg"
          >
            Start New Survey
          </Link>
          <Link
            to="/dashboard"
            className="bg-forest-700 hover:bg-forest-600 transition-colors text-white font-semibold px-6 py-3 rounded-lg border border-forest-500"
          >
            View Dashboard
          </Link>
        </div>
      </header>

      <section className="max-w-4xl mx-auto px-6 pb-16">
        <div className="flex flex-wrap items-center justify-center gap-4">
          {steps.map((s, i) => (
            <div key={s.label} className="flex items-center gap-4">
              <div className="flex flex-col items-center gap-2 w-28">
                <div className="bg-forest-700 border border-forest-500 rounded-full p-3">
                  <s.icon size={22} className="text-accent-400" />
                </div>
                <span className="text-xs text-center text-forest-200">{s.label}</span>
              </div>
              {i < steps.length - 1 && <span className="text-forest-500 hidden sm:block">→</span>}
            </div>
          ))}
        </div>
      </section>

      <section className="bg-earth-50 text-forest-900 rounded-t-3xl">
        <div className="max-w-5xl mx-auto px-6 py-14 grid sm:grid-cols-2 gap-8">
          <div>
            <h2 className="font-bold text-forest-700 mb-1">The Problem</h2>
            <p className="text-sm text-forest-600">
              Manual wildlife counting can require significant time and effort.
            </p>
          </div>
          <div>
            <h2 className="font-bold text-forest-700 mb-1">Our Solution</h2>
            <p className="text-sm text-forest-600">
              Game Count uses computer vision to assist with the initial counting process.
            </p>
          </div>
          <div>
            <h2 className="font-bold text-forest-700 mb-1">The Human Element</h2>
            <p className="text-sm text-forest-600">
              The ranger remains responsible for reviewing and verifying the result.
            </p>
          </div>
          <div>
            <h2 className="font-bold text-forest-700 mb-1">The Goal</h2>
            <p className="text-sm text-forest-600">
              Reduce the time required to process wildlife survey imagery.
            </p>
          </div>
        </div>
        <p className="text-center text-xs text-forest-400 pb-6 px-6">
          AI-generated counts are estimates and should be reviewed by qualified conservation personnel before being
          used for management decisions.
        </p>
      </section>
    </div>
  );
}
