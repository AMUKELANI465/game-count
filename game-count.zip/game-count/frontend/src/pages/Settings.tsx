import { useEffect, useState } from "react";
import { api } from "../services/api";

export default function Settings() {
  const [health, setHealth] = useState<{ demo_mode: boolean; species_supported: string[] } | null>(null);

  useEffect(() => {
    api.health().then(setHealth).catch(() => setHealth(null));
  }, []);

  return (
    <div className="p-6 max-w-2xl mx-auto">
      <h1 className="text-2xl font-bold text-forest-800 mb-1">Settings</h1>
      <p className="text-sm text-forest-500 mb-6">Current system configuration</p>

      <div className="bg-white border border-earth-200 rounded-xl p-5 shadow-sm space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium text-forest-700">AI Mode</span>
          <span
            className={`text-xs font-bold px-3 py-1 rounded-full ${
              health?.demo_mode ? "bg-accent-500/20 text-accent-600" : "bg-forest-100 text-forest-700"
            }`}
          >
            {health ? (health.demo_mode ? "DEMO / SIMULATED" : "LIVE (YOLO)") : "Checking..."}
          </span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm font-medium text-forest-700">Species monitored</span>
          <span className="text-sm text-forest-500 capitalize">{health?.species_supported.join(", ") || "—"}</span>
        </div>
        <div className="text-xs text-forest-400 pt-2 border-t border-earth-100">
          To switch to live detection, set <code className="bg-earth-100 px-1 rounded">DEMO_MODE=false</code> and{" "}
          <code className="bg-earth-100 px-1 rounded">MODEL_PATH</code> in the backend's <code>.env</code> file, then
          restart the server. See <code>ai/README.md</code> for training a wildlife-specific model.
        </div>
      </div>
    </div>
  );
}
