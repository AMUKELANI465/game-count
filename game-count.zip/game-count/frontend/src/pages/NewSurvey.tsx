import { useNavigate } from "react-router-dom";
import { useRef, useState } from "react";
import { UploadCloud, Image as ImageIcon, Loader2 } from "lucide-react";
import { api } from "../services/api";

export default function NewSurvey() {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [surveyName, setSurveyName] = useState("");
  const [surveyDate, setSurveyDate] = useState(new Date().toISOString().slice(0, 10));
  const [location, setLocation] = useState("");
  const [notes, setNotes] = useState("");

  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState("");

  const acceptTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"];

  function handleFile(f: File) {
    setError("");
    if (!acceptTypes.includes(f.type)) {
      setError("Please upload a JPG, PNG or WEBP image.");
      return;
    }
    if (f.size > 20 * 1024 * 1024) {
      setError("Image is too large. Maximum size is 20MB.");
      return;
    }
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files?.[0]) handleFile(e.dataTransfer.files[0]);
  }

  async function handleAnalyze() {
    if (!surveyName.trim()) {
      setError("Please give this survey a name.");
      return;
    }
    if (!file) {
      setError("Please upload an aerial image first.");
      return;
    }
    setError("");
    setAnalyzing(true);
    try {
      const result = await api.analyze(file);
      // Pass survey metadata + AI result forward via router state.
      navigate("/analysis", {
        state: {
          survey: { survey_name: surveyName, survey_date: surveyDate, location, notes },
          result,
        },
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Analysis failed.");
    } finally {
      setAnalyzing(false);
    }
  }

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-forest-800 mb-1">New Survey</h1>
      <p className="text-sm text-forest-500 mb-6">Enter survey details, then upload an aerial image to analyse.</p>

      <div className="bg-white border border-earth-200 rounded-xl p-6 shadow-sm space-y-4 mb-6">
        <div>
          <label htmlFor="survey-name" className="block text-sm font-semibold text-forest-700 mb-1">
            Survey Name
          </label>
          <input
            id="survey-name"
            type="text"
            value={surveyName}
            onChange={(e) => setSurveyName(e.target.value)}
            placeholder="e.g. Aerial Survey #005"
            className="w-full border border-earth-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-forest-400"
          />
        </div>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="survey-date" className="block text-sm font-semibold text-forest-700 mb-1">
              Survey Date
            </label>
            <input
              id="survey-date"
              type="date"
              value={surveyDate}
              onChange={(e) => setSurveyDate(e.target.value)}
              className="w-full border border-earth-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-forest-400"
            />
          </div>
          <div>
            <label htmlFor="survey-location" className="block text-sm font-semibold text-forest-700 mb-1">
              Survey Location
            </label>
            <input
              id="survey-location"
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="e.g. Northern Section"
              className="w-full border border-earth-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-forest-400"
            />
          </div>
        </div>
        <div>
          <label htmlFor="survey-notes" className="block text-sm font-semibold text-forest-700 mb-1">
            Notes
          </label>
          <textarea
            id="survey-notes"
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={3}
            placeholder="Optional notes about weather, visibility, flight path..."
            className="w-full border border-earth-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-forest-400"
          />
        </div>
      </div>

      <div className="bg-white border border-earth-200 rounded-xl p-6 shadow-sm">
        <h2 className="text-sm font-semibold text-forest-700 mb-3">Upload aerial wildlife imagery</h2>

        <div
          role="button"
          tabIndex={0}
          onClick={() => fileInputRef.current?.click()}
          onKeyDown={(e) => e.key === "Enter" && fileInputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDragActive(true);
          }}
          onDragLeave={() => setDragActive(false)}
          onDrop={onDrop}
          className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-colors ${
            dragActive ? "border-accent-500 bg-accent-400/10" : "border-earth-300 hover:border-forest-400"
          }`}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp"
            className="hidden"
            aria-label="Upload aerial wildlife image"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
          {previewUrl ? (
            <img src={previewUrl} alt="Selected aerial preview" className="max-h-64 mx-auto rounded-lg" />
          ) : (
            <div className="flex flex-col items-center gap-2 text-forest-500">
              <UploadCloud size={36} />
              <span className="font-medium">Upload aerial wildlife imagery</span>
              <span className="text-xs">JPG, PNG or WEBP · up to 20MB</span>
            </div>
          )}
        </div>

        {file && (
          <div className="flex items-center gap-2 text-xs text-forest-500 mt-3">
            <ImageIcon size={14} /> {file.name} ({(file.size / (1024 * 1024)).toFixed(1)} MB)
          </div>
        )}

        {error && <p className="text-red-600 text-sm mt-3">{error}</p>}

        <button
          onClick={handleAnalyze}
          disabled={analyzing}
          className="mt-5 w-full sm:w-auto bg-forest-600 hover:bg-forest-700 disabled:opacity-60 text-white font-semibold px-6 py-3 rounded-lg flex items-center justify-center gap-2"
        >
          {analyzing ? (
            <>
              <Loader2 className="animate-spin" size={18} /> Analysing...
            </>
          ) : (
            "Analyse with AI"
          )}
        </button>
      </div>
    </div>
  );
}
