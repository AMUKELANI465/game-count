import { useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import { CheckCircle2, Loader2 } from "lucide-react";
import { api, SPECIES_EMOJI } from "../services/api";
import type { AnalyzeResult } from "../types";

interface NavState {
  survey: { survey_name: string; survey_date: string; location: string; notes: string };
  result: AnalyzeResult;
}

export default function Results() {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as NavState | undefined;

  const [verified, setVerified] = useState<Record<string, number>>(
    () => (state ? { ...state.result.species_counts } : {})
  );
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  if (!state) {
    return (
      <div className="p-6 max-w-2xl mx-auto text-center text-forest-500">
        No results to review.{" "}
        <button className="text-accent-500 underline font-semibold" onClick={() => navigate("/new-survey")}>
          Start a new survey
        </button>
        .
      </div>
    );
  }

  const { survey, result } = state;
  const aiTotal = result.total_animals;
  const verifiedTotal = Object.values(verified).reduce((a, b) => a + Number(b || 0), 0);
  const difference = aiTotal - verifiedTotal;

  function updateCount(species: string, value: string) {
    const num = Math.max(0, parseInt(value, 10) || 0);
    setVerified((prev) => ({ ...prev, [species]: num }));
  }

  async function handleSave() {
    setSaving(true);
    setError("");
    try {
      await api.createSurvey({
        survey_name: survey.survey_name,
        survey_date: survey.survey_date,
        location: survey.location,
        notes: survey.notes,
        image_path: result.image_path,
        annotated_image_path: result.annotated_image_path,
        ai_total: aiTotal,
        verified_total: verifiedTotal,
        average_confidence: result.average_confidence,
        processing_time: result.processing_time,
        status: "verified",
        species_counts: Object.entries(result.species_counts).map(([species, ai_count]) => ({
          species,
          ai_count,
          verified_count: verified[species] ?? ai_count,
        })),
      });
      setSaved(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save survey.");
    } finally {
      setSaving(false);
    }
  }

  if (saved) {
    return (
      <div className="p-6 max-w-lg mx-auto text-center mt-12">
        <CheckCircle2 className="mx-auto text-forest-500 mb-3" size={48} />
        <h1 className="text-xl font-bold text-forest-800 mb-2">Survey saved</h1>
        <p className="text-sm text-forest-500 mb-6">
          The verified census for "{survey.survey_name}" has been recorded.
        </p>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <button
            onClick={() => navigate("/new-survey")}
            className="bg-forest-600 hover:bg-forest-700 text-white font-semibold px-5 py-2.5 rounded-lg"
          >
            Run Another Analysis
          </button>
          <button
            onClick={() => navigate("/surveys")}
            className="bg-white border border-earth-300 hover:border-forest-400 text-forest-700 font-semibold px-5 py-2.5 rounded-lg"
          >
            View Survey History
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold text-forest-800 mb-1">Census Results</h1>
      <p className="text-sm text-forest-500 mb-6">{survey.survey_name || "Untitled survey"}</p>

      <div className="grid sm:grid-cols-2 gap-6 mb-6">
        <div className="bg-white border border-earth-200 rounded-xl p-5 shadow-sm">
          <h2 className="text-xs font-bold uppercase tracking-wide text-forest-500 mb-3">AI Estimate</h2>
          <div className="text-3xl font-bold text-forest-800 mb-3">{aiTotal} animals</div>
          <div className="space-y-1 text-sm">
            {Object.entries(result.species_counts).map(([species, count]) => (
              <div key={species} className="flex justify-between text-forest-600">
                <span className="capitalize">
                  {SPECIES_EMOJI[species]} {species}
                </span>
                <span className="font-semibold">{count}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white border-2 border-forest-300 rounded-xl p-5 shadow-sm">
          <h2 className="text-xs font-bold uppercase tracking-wide text-forest-600 mb-3">Ranger Verified Count</h2>
          <div className="space-y-3">
            {Object.entries(result.species_counts).map(([species, aiCount]) => (
              <div key={species} className="flex items-center justify-between">
                <div>
                  <div className="text-sm font-medium capitalize">
                    {SPECIES_EMOJI[species]} {species}
                  </div>
                  <div className="text-[11px] text-forest-400">AI estimate: {aiCount}</div>
                </div>
                <input
                  type="number"
                  min={0}
                  aria-label={`Verified count for ${species}`}
                  value={verified[species] ?? aiCount}
                  onChange={(e) => updateCount(species, e.target.value)}
                  className="w-20 border border-earth-300 rounded-lg px-2 py-1.5 text-sm text-right focus:outline-none focus:ring-2 focus:ring-forest-400"
                />
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-forest-800 text-white rounded-xl p-5 flex flex-wrap gap-6 justify-around text-center mb-6">
        <div>
          <div className="text-xs uppercase tracking-wide text-forest-300">AI Estimate</div>
          <div className="text-2xl font-bold">{aiTotal}</div>
        </div>
        <div>
          <div className="text-xs uppercase tracking-wide text-forest-300">Ranger Verified</div>
          <div className="text-2xl font-bold">{verifiedTotal}</div>
        </div>
        <div>
          <div className="text-xs uppercase tracking-wide text-forest-300">Difference</div>
          <div className="text-2xl font-bold text-accent-400">{Math.abs(difference)}</div>
        </div>
      </div>

      {error && <p className="text-red-600 text-sm mb-4">{error}</p>}

      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex-1 bg-forest-600 hover:bg-forest-700 disabled:opacity-60 text-white font-semibold py-3 rounded-lg flex items-center justify-center gap-2"
        >
          {saving ? (
            <>
              <Loader2 className="animate-spin" size={18} /> Saving...
            </>
          ) : (
            "Save Survey"
          )}
        </button>
        <button
          onClick={() => navigate("/new-survey")}
          className="flex-1 bg-white border border-earth-300 hover:border-forest-400 text-forest-700 font-semibold py-3 rounded-lg"
        >
          Run Another Analysis
        </button>
        <button
          onClick={() => navigate("/surveys")}
          className="flex-1 bg-white border border-earth-300 hover:border-forest-400 text-forest-700 font-semibold py-3 rounded-lg"
        >
          View Survey History
        </button>
      </div>
    </div>
  );
}
