import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { api, SPECIES_EMOJI } from "../services/api";
import type { Survey } from "../types";

export default function SurveyDetail() {
  const { id } = useParams();
  const [survey, setSurvey] = useState<Survey | null>(null);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!id) return;
    api
      .getSurvey(Number(id))
      .then(setSurvey)
      .catch((e) => setError(e.message));
  }, [id]);

  if (error) return <div className="p-6 text-red-600 text-sm">{error}</div>;
  if (!survey) return <div className="p-6 text-forest-500 text-sm">Loading...</div>;

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <Link to="/surveys" className="inline-flex items-center gap-1 text-sm text-forest-500 hover:text-forest-700 mb-4">
        <ArrowLeft size={16} /> Back to survey history
      </Link>

      <h1 className="text-2xl font-bold text-forest-800 mb-1">{survey.survey_name}</h1>
      <p className="text-sm text-forest-500 mb-6">
        {survey.survey_date || survey.created_at.slice(0, 10)} · {survey.location || "Location not recorded"}
      </p>

      <div className="grid lg:grid-cols-2 gap-4 mb-6">
        {survey.image_path && (
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wide text-forest-500 mb-2">Original Image</h2>
            <img src={survey.image_path} alt="Original aerial survey" className="w-full rounded-lg border border-earth-200" />
          </div>
        )}
        {survey.annotated_image_path && (
          <div>
            <h2 className="text-xs font-bold uppercase tracking-wide text-forest-500 mb-2">Annotated Image</h2>
            <img
              src={survey.annotated_image_path}
              alt="Annotated aerial survey with detections"
              className="w-full rounded-lg border border-earth-200"
            />
          </div>
        )}
      </div>

      <div className="grid sm:grid-cols-3 gap-4 mb-6">
        <div className="bg-white border border-earth-200 rounded-xl p-4 text-center">
          <div className="text-xs uppercase text-forest-500 font-semibold">AI Total</div>
          <div className="text-2xl font-bold text-forest-800">{survey.ai_total}</div>
        </div>
        <div className="bg-white border border-earth-200 rounded-xl p-4 text-center">
          <div className="text-xs uppercase text-forest-500 font-semibold">Verified Total</div>
          <div className="text-2xl font-bold text-forest-800">{survey.verified_total}</div>
        </div>
        <div className="bg-white border border-earth-200 rounded-xl p-4 text-center">
          <div className="text-xs uppercase text-forest-500 font-semibold">Avg. Confidence</div>
          <div className="text-2xl font-bold text-forest-800">{Math.round(survey.average_confidence * 100)}%</div>
        </div>
      </div>

      <div className="bg-white border border-earth-200 rounded-xl p-5 mb-6">
        <h2 className="text-xs font-bold uppercase tracking-wide text-forest-500 mb-3">Species Breakdown</h2>
        <div className="space-y-2">
          {survey.species_counts.map((sc) => (
            <div key={sc.species} className="flex justify-between items-center text-sm border-b border-earth-100 pb-2 last:border-0">
              <span className="capitalize font-medium">
                {SPECIES_EMOJI[sc.species]} {sc.species}
              </span>
              <span className="text-forest-500">
                AI: <span className="font-semibold text-forest-800">{sc.ai_count}</span> · Verified:{" "}
                <span className="font-semibold text-forest-800">{sc.verified_count}</span>
              </span>
            </div>
          ))}
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-4 text-sm text-forest-600">
        <div>
          <span className="font-semibold text-forest-700">Processing time:</span> {survey.processing_time.toFixed(1)}s
        </div>
        <div>
          <span className="font-semibold text-forest-700">Created:</span> {survey.created_at.slice(0, 10)}
        </div>
        {survey.notes && (
          <div className="sm:col-span-2">
            <span className="font-semibold text-forest-700">Notes:</span> {survey.notes}
          </div>
        )}
      </div>
    </div>
  );
}
