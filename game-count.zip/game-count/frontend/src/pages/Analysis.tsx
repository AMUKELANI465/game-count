import { useLocation, useNavigate } from "react-router-dom";
import { AlertTriangle } from "lucide-react";
import DetectionImage from "../components/DetectionImage";
import { SPECIES_EMOJI } from "../services/api";
import type { AnalyzeResult } from "../types";

interface NavState {
  survey: { survey_name: string; survey_date: string; location: string; notes: string };
  result: AnalyzeResult;
}

export default function Analysis() {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as NavState | undefined;

  if (!state) {
    return (
      <div className="p-6 max-w-2xl mx-auto text-center text-forest-500">
        No analysis in progress.{" "}
        <button className="text-accent-500 underline font-semibold" onClick={() => navigate("/new-survey")}>
          Start a new survey
        </button>
        .
      </div>
    );
  }

  const { survey, result } = state;
  const speciesEntries = Object.entries(result.species_counts);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      {result.demo && (
        <div className="demo-banner text-white text-xs font-bold uppercase tracking-wide text-center py-1.5 rounded-lg mb-4">
          Demo / Simulated AI Results
        </div>
      )}

      <h1 className="text-2xl font-bold text-forest-800 mb-1">AI Analysis</h1>
      <p className="text-sm text-forest-500 mb-6">{survey.survey_name || "Untitled survey"}</p>

      {!result.detections.length && (
        <div className="bg-amber-50 border border-amber-300 text-amber-800 rounded-lg p-4 flex gap-3 mb-6 text-sm">
          <AlertTriangle size={20} className="shrink-0" />
          <p>{result.message || "No animals detected. Please review the image manually."}</p>
        </div>
      )}

      <div className="grid lg:grid-cols-[1.4fr_1fr] gap-6">
        <div>
          <DetectionImage imageUrl={result.image_url} detections={result.detections} />
        </div>

        <div className="bg-white border border-earth-200 rounded-xl p-5 shadow-sm h-fit">
          <h2 className="text-sm font-bold text-forest-700 uppercase tracking-wide mb-4">AI Analysis</h2>

          <dl className="space-y-2 text-sm mb-5">
            <Row label="Status" value="Analysis complete" />
            <Row label="Animals detected" value={result.total_animals} />
            <Row label="Species" value={speciesEntries.filter(([, c]) => c > 0).length} />
            <Row label="Average confidence" value={`${Math.round(result.average_confidence * 100)}%`} />
            <Row label="Processing time" value={`${result.processing_time.toFixed(1)}s`} />
          </dl>

          <h3 className="text-xs font-bold text-forest-500 uppercase tracking-wide mb-2">Species breakdown</h3>
          <div className="space-y-2 mb-5">
            {speciesEntries.map(([species, count]) => {
              const confs = result.detections.filter((d) => d.species === species).map((d) => d.confidence);
              const avgConf = confs.length ? confs.reduce((a, b) => a + b, 0) / confs.length : 0;
              return (
                <div key={species} className="flex items-center justify-between bg-earth-50 rounded-lg px-3 py-2">
                  <span className="text-sm font-medium capitalize flex items-center gap-2">
                    <span>{SPECIES_EMOJI[species]}</span> {species}
                  </span>
                  <span className="text-xs text-forest-500 text-right">
                    <span className="font-bold text-forest-800">{count}</span> detected
                    <br />
                    {Math.round(avgConf * 100)}% confidence
                  </span>
                </div>
              );
            })}
          </div>

          <p className="text-[11px] text-forest-400 mb-4">
            Confidence represents the model's confidence in a detection. It does not guarantee that the detection is
            correct.
          </p>

          <button
            onClick={() => navigate("/results", { state })}
            className="w-full bg-forest-600 hover:bg-forest-700 text-white font-semibold py-3 rounded-lg"
          >
            Review Results
          </button>
        </div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex justify-between">
      <dt className="text-forest-500">{label}</dt>
      <dd className="font-semibold text-forest-800">{value}</dd>
    </div>
  );
}
