import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { api } from "../services/api";
import type { Survey } from "../types";
import { SPECIES } from "../constants";

const SPECIES_COLORS: Record<string, string> = {
  elephant: "#2F5233",
  giraffe: "#C97B2C",
  impala: "#8C6239",
  springbok: "#4C7A5A",
};

export default function Analytics() {
  const [surveys, setSurveys] = useState<Survey[]>([]);

  useEffect(() => {
    api.listSurveys().then(setSurveys).catch(() => setSurveys([]));
  }, []);

  const totalAnimals = surveys.reduce((sum, s) => sum + (s.verified_total || 0), 0);
  const speciesTotals: Record<string, number> = Object.fromEntries(SPECIES.map((s) => [s, 0]));
  surveys.forEach((s) =>
    s.species_counts.forEach((sc) => {
      speciesTotals[sc.species] = (speciesTotals[sc.species] || 0) + sc.verified_count;
    })
  );
  const pieData = SPECIES.map((s) => ({ name: s, value: speciesTotals[s] })).filter((d) => d.value > 0);

  const comparisonData = [...surveys].reverse().map((s, i) => ({
    name: `#${i + 1}`,
    "AI estimate": s.ai_total,
    "Ranger verified": s.verified_total,
  }));

  if (!surveys.length) {
    return (
      <div className="p-6 max-w-5xl mx-auto text-center text-forest-500">
        No survey data yet - analytics will populate once surveys are saved.
      </div>
    );
  }

  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-2xl font-bold text-forest-800 mb-1">Analytics</h1>
      <p className="text-sm text-forest-500 mb-6">
        {totalAnimals} animals recorded across {surveys.length} surveys.
      </p>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white border border-earth-200 rounded-xl p-5 shadow-sm">
          <h2 className="text-sm font-semibold text-forest-700 mb-4">Species distribution (verified)</h2>
          <div style={{ width: "100%", height: 260 }}>
            <ResponsiveContainer>
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" outerRadius={90} label>
                  {pieData.map((entry) => (
                    <Cell key={entry.name} fill={SPECIES_COLORS[entry.name]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white border border-earth-200 rounded-xl p-5 shadow-sm">
          <h2 className="text-sm font-semibold text-forest-700 mb-4">AI estimate vs. ranger verified</h2>
          <div style={{ width: "100%", height: 260 }}>
            <ResponsiveContainer>
              <BarChart data={comparisonData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e2d2b8" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="#8c6239" />
                <YAxis tick={{ fontSize: 11 }} stroke="#8c6239" />
                <Tooltip />
                <Legend />
                <Bar dataKey="AI estimate" fill="#C97B2C" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Ranger verified" fill="#2F5233" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
}
