import { useEffect, useState } from "react";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import "leaflet/dist/leaflet.css";
import L from "leaflet";
import { api } from "../services/api";
import type { Survey } from "../types";

// Fix default marker icons not loading under Vite's bundler.
delete (L.Icon.Default.prototype as unknown as { _getIconUrl?: unknown })._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
});

// Approximate centre of Welgevonden Game Reserve, Limpopo, South Africa -
// used as the map's starting view. Individual surveys are not plotted at
// real GPS coordinates since no GPS data is captured in this MVP; markers
// are placed here only to represent that a survey exists for the reserve.
const RESERVE_CENTER: [number, number] = [-24.2, 27.85];

export default function MapPage() {
  const [surveys, setSurveys] = useState<Survey[]>([]);

  useEffect(() => {
    api.listSurveys().then(setSurveys).catch(() => setSurveys([]));
  }, []);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold text-forest-800 mb-1">Map</h1>
      <p className="text-sm text-forest-500 mb-4">
        Survey organization for Welgevonden Game Reserve. Markers indicate that a survey exists - they are not exact
        animal GPS locations.
      </p>

      <div className="rounded-xl overflow-hidden border border-earth-200 shadow-sm" style={{ height: 480 }}>
        <MapContainer center={RESERVE_CENTER} zoom={11} style={{ height: "100%", width: "100%" }}>
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          />
          {surveys.map((s, i) => (
            <Marker
              key={s.id}
              // Small deterministic offset per survey so multiple markers
              // don't stack exactly on top of one another.
              position={[RESERVE_CENTER[0] + i * 0.01, RESERVE_CENTER[1] + i * 0.01]}
            >
              <Popup>
                <strong>{s.survey_name}</strong>
                <br />
                {s.location || "Location not recorded"}
                <br />
                Verified count: {s.verified_total}
              </Popup>
            </Marker>
          ))}
        </MapContainer>
      </div>
    </div>
  );
}
