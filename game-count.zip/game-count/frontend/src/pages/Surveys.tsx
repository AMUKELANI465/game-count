import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { api } from "../services/api";
import type { Survey } from "../types";

export default function Surveys() {
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .listSurveys()
      .then(setSurveys)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-forest-800">Surveys</h1>
          <p className="text-sm text-forest-500">All recorded census surveys</p>
        </div>
        <Link to="/new-survey" className="bg-accent-500 hover:bg-accent-600 text-white text-sm font-semibold px-4 py-2 rounded-lg">
          + New Survey
        </Link>
      </div>

      {error && <p className="text-red-600 text-sm mb-4">Could not load surveys: {error}</p>}

      {loading ? (
        <p className="text-forest-500 text-sm">Loading...</p>
      ) : surveys.length === 0 ? (
        <div className="bg-white border border-earth-200 rounded-xl p-10 text-center text-forest-500">
          No surveys recorded yet.
        </div>
      ) : (
        <div className="bg-white border border-earth-200 rounded-xl overflow-hidden shadow-sm">
          <table className="w-full text-sm">
            <thead className="bg-earth-100 text-forest-600 text-xs uppercase tracking-wide">
              <tr>
                <th className="text-left px-4 py-3">Survey</th>
                <th className="text-left px-4 py-3">Date</th>
                <th className="text-left px-4 py-3">Location</th>
                <th className="text-right px-4 py-3">AI Count</th>
                <th className="text-right px-4 py-3">Verified Count</th>
                <th className="text-left px-4 py-3">Status</th>
              </tr>
            </thead>
            <tbody>
              {surveys.map((s) => (
                <tr key={s.id} className="border-t border-earth-100 hover:bg-earth-50 cursor-pointer">
                  <td className="px-4 py-3">
                    <Link to={`/surveys/${s.id}`} className="font-medium text-forest-800 hover:text-accent-500">
                      {s.survey_name}
                    </Link>
                  </td>
                  <td className="px-4 py-3 text-forest-500">{s.survey_date || s.created_at.slice(0, 10)}</td>
                  <td className="px-4 py-3 text-forest-500">{s.location || "—"}</td>
                  <td className="px-4 py-3 text-right font-semibold text-forest-700">{s.ai_total}</td>
                  <td className="px-4 py-3 text-right font-semibold text-forest-700">{s.verified_total}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`text-xs font-semibold px-2 py-1 rounded-full ${
                        s.status === "verified"
                          ? "bg-forest-100 text-forest-700"
                          : "bg-earth-100 text-earth-500"
                      }`}
                    >
                      {s.status === "verified" ? "Verified" : "Draft"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
