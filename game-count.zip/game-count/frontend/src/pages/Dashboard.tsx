import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer } from "recharts";
import { PawPrint, ClipboardList, Layers, CalendarClock } from "lucide-react";
import { api, SPECIES_EMOJI } from "../services/api";
import type { Survey } from "../types";
import StatCard from "../components/StatCard";
import { SPECIES } from "../constants";

export default function Dashboard() {
  const [surveys, setSurveys] = useState<Survey[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .listSurveys()
      .then(setSurveys)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const totalAnimals = surveys.reduce((sum, s) => sum + (s.verified_total || s.ai_total || 0), 0);
  const surveysCompleted = surveys.filter((s) => s.status === "verified").length;
  const latestSurvey = surveys[0]?.survey_date || surveys[0]?.created_at?.slice(0, 10) || "—";

  const speciesTotals: Record<string, number> = Object.fromEntries(SPECIES.map((s) => [s, 0]));
  surveys.forEach((s) =>
    s.species_counts.forEach((sc) => {
      speciesTotals[sc.species] = (speciesTotals[sc.species] || 0) + (sc.verified_count ?? sc.ai_count);
    })
  );

  const chartData = [...surveys]
    .reverse()
    .map((s, i) => ({
      name: `Survey ${String(i + 1).padStart(3, "0")}`,
      count: s.verified_total || s.ai_total,
    }));

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <div className="flex items-center justify-between flex-wrap gap-3 mb-6">
        <div>
          <h1 className="text-2xl font-bold text-forest-800">Dashboard</h1>
          <p className="text-sm text-forest-500">Overview of your wildlife census activity</p>
        </div>
        <Link to="/new-survey" className="bg-accent-500 hover:bg-accent-600 text-white text-sm font-semibold px-4 py-2 rounded-lg">
          + New Survey
        </Link>
      </div>

      {error && <p className="text-red-600 text-sm mb-4">Could not load surveys: {error}</p>}
      {loading ? (
        <p className="text-forest-500 text-sm">Loading...</p>
      ) : surveys.length === 0 ? (
        <div className="bg-white border border-earth-200 rounded-xl p-10 text-center text-forest-500">
          No surveys yet.{" "}
          <Link to="/new-survey" className="text-accent-500 font-semibold underline">
            Create your first survey
          </Link>{" "}
          to see it here.
        </div>
      ) : (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <StatCard label="Total Animals" value={totalAnimals} icon={<PawPrint size={28} />} />
            <StatCard label="Surveys Completed" value={surveysCompleted} icon={<ClipboardList size={28} />} />
            <StatCard label="Species Monitored" value={SPECIES.length} icon={<Layers size={28} />} />
            <StatCard label="Latest Survey" value={latestSurvey} icon={<CalendarClock size={28} />} />
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {SPECIES.map((species) => (
              <div key={species} className="bg-white border border-earth-200 rounded-xl p-5 text-center shadow-sm">
                <div className="text-3xl mb-1">{SPECIES_EMOJI[species]}</div>
                <div className="text-xs uppercase tracking-wide text-forest-500 font-semibold capitalize">{species}</div>
                <div className="text-2xl font-bold text-forest-800 mt-1">{speciesTotals[species]}</div>
              </div>
            ))}
          </div>

          <div className="bg-white border border-earth-200 rounded-xl p-5 shadow-sm">
            <h2 className="text-sm font-semibold text-forest-700 mb-1">Recorded survey counts</h2>
            <p className="text-xs text-forest-400 mb-4">
              Reflects recorded results per survey - not a guaranteed measure of population trend.
            </p>
            <div style={{ width: "100%", height: 260 }}>
              <ResponsiveContainer>
                <LineChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e2d2b8" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} stroke="#8c6239" />
                  <YAxis tick={{ fontSize: 11 }} stroke="#8c6239" />
                  <Tooltip />
                  <Line type="monotone" dataKey="count" stroke="#2F5233" strokeWidth={2} dot={{ r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
